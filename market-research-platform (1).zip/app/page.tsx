import MarketIntelligenceTool from "../market-intelligence-tool"

export default function Page() {
  return <MarketIntelligenceTool />
}
